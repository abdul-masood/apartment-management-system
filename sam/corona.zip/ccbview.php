<!DOCTYPE html>
<html lang="en">
<head>
  <title>Covid Care Center </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"> </script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"> </script>
  <script         src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

</head>
<body style="bgcolor:red;background-image:url('p.jpg');background-repeat:no-repeat;background-size:1550px ;">
<center>
<h3><b><u>Branches Of Care Center</b></u></h3></center>

<?php
$connection = new mysqli('localhost','root','','coronacarecenter'); //The Blank string is the password


$sql = "SELECT * FROM covidcarecentre";
$result =  $connection->query($sql);
//echo "Details of Patient";
echo "<table width='800' border='1' align='center' >"; 
// start a table tag in the HTML
echo"<tr>
	<th>ID</th>
	<th>Address</th>
	<th>Manager</th>
	<th>Phone Number</th>
	
	</tr>";
while($row = $result->fetch_array(MYSQLI_BOTH)){   //Creates a loop to loop through results
echo "<tr border: '1px solid black'><td border: '1px solid black'>" . $row['cid'] . "</td>
		<td border: '1px solid black'>" . $row['CAddress'] . "</td>
		<td border: '1px solid black'>" . $row['CManager'] . "</td>
		<td border: '1px solid black'>" . $row['CPhone'] . "</td>
		
		</tr>";  //$row['index'] the index here is a field name
}

echo "</table>"; //Close the table in HTML

//mysql_close();
?><br/>
<center><a href="coronahome.php" class="btn btn-danger">HomePage</a>
</center>
</body>
</head>
</html>