
<?php
if($_POST['finalsubmit'])
{
   //Save Code

	$Phno=$_POST['Phno'];
    $Particulars=$_POST['Particulars'];
    $Amount=$_POST['Amount'];
	
    
    
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    else {
        $stmt=$conn->prepare("insert into billing(Phno,Particulars,Amount)
            values(?,?,?)");
            $stmt->bind_param("isi",$Phno,$Particulars,$Amount);
			   // mysql_query("UPDATE patient SET DischargeDate = '$DischargeDate'WHERE Phno = $Phno");

            $stmt->execute();
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: coronahome.php");
           // include 'home.php';
            $stmt->close();
           // $conn->close();
    }

}
        else if($_POST['submit'])
{
   //Save Code

	$Phno=$_POST['Phno'];
    $Particulars=$_POST['Particulars'];
    $Amount=$_POST['Amount'];
	
    
    
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    else {
        $stmt=$conn->prepare("insert into billing(Phno,Particulars,Amount)
            values(?,?,?)");
            $stmt->bind_param("isi",$Phno,$Particulars,$Amount);
			   // mysql_query("UPDATE patient SET DischargeDate = '$DischargeDate'WHERE Phno = $Phno");

            $stmt->execute();
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: billing.php");
           // include 'home.php';
            $stmt->close();
           // $conn->close();
    }

}
?>