<?php

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname1 = "demo";
//$dbname2 = "registr"; /* Database name */

$db = mysqli_connect($host ,$user,$password,$dbname1);//coonect db
//$con2 = mysqli_connect($host ,$user,$password,$dbname2);
// Check connection
if (!$db) {
 die("Connection failed: " . mysqli_connect_error());
}