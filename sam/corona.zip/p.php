<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie-edge">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js'></script>
        <link href='https://fonts.googleapis.com/css?family=KronaOne' rel='stylesheet'>
        <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
         <link rel="icon" type="image/png" href="assets/img/favicon.ico">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <title>Doctor Register Form</title>
         <style>
		 @media screen and (max-width: 600px) {
			  .column {
				width: 100%;
				display: block;
				margin-bottom: 20px;
			  }
			}
			
			#t1{
				border: solid black;
			}
					
		input[type=radio] {
		  border: 1px solid black;
		  padding: 0.5em;
		  -webkit-appearance: none;
		  background-color: white;
		  outline-color: solid black;
		}

		input[type=radio]:checked {
		  background: black;
		  background-size: 9px 9px;
		  outline-color: solid black;
		  color: black;
		}

		input[type=radio]:focus {
		  outline-color: solid black;
		}
		.b{
			background-color: orange;
			color: black;
			border: 4px solid white;
			border-radius: 5px;
			width: 150px;
			
		}

		 </style>
	</head>
	<body style="background-image:url('bg-01.jpg')">
	 <form  name="f1" action="ptr.php"   method="POST">
		<center><h1><b>Patient Test Report</b></h1></center>
		<div class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
				<label for="Phno">Patient Phone Number</label>
			</div>
			<div class="col-sm-4">
				<input type="text" class="form-control" name="Phno" id="t1" required>
			</div>
		</div><br/>
		
		<div class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
				<label for="TestType">Test Type</label>
			</div>
			<div class="col-sm-4">
				<input type="radio" name="TestType" value="RT-PCR" id="t1"> RT-PCR &nbsp &nbsp &nbsp &nbsp <input type="radio" name="TestType" value="RAPID ANTIGEN"  id="t1"> RAPID ANTIGEN
				 &nbsp &nbsp
				 
			</div>
		</div><br/>
		<div class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
				<label for="Report">Report</label>
			</div>
			<div class="col-sm-4">
				<input type="radio" name="Report" value="POSITIVE" id="t1"> POSITIVE &nbsp &nbsp &nbsp &nbsp <input type="radio" name="Report" value="NEGATIVE"  id="t1"> NEGATIVE &nbsp &nbsp
				 &nbsp &nbsp
			</div>
		</div><br/>
		<div class="row">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
				<label for="DateofTest">Date of Test</label>
			</div>
			<div class="col-sm-4">
				<input type="date" class="form-control" name="DateofTest" id="t1" required>
			</div>
		</div><br/>
		
				
		
		<center><input type="submit" value="Register" class="btn b"></center>
	 </form>
	</body>
</html>
	