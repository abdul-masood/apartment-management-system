-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2021 at 10:28 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coronacarecenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `Bid` int(10) NOT NULL,
  `Phno` bigint(12) NOT NULL,
  `Particulars` varchar(20) NOT NULL,
  `Amount` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`Bid`, `Phno`, `Particulars`, `Amount`) VALUES
(1, 8965741589, 'food', 1000),
(2, 8965741589, 'Medicine', 5000),
(3, 8965741589, 'Bed', 2000),
(4, 8965741589, 'Food', 200),
(5, 8974589652, 'Bed', 500),
(6, 8974589652, 'Food', 500);

-- --------------------------------------------------------

--
-- Table structure for table `covidcarecentre`
--

CREATE TABLE `covidcarecentre` (
  `cid` int(10) NOT NULL,
  `CAddress` varchar(50) NOT NULL,
  `CManager` varchar(20) NOT NULL,
  `CPhone` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `covidcarecentre`
--

INSERT INTO `covidcarecentre` (`cid`, `CAddress`, `CManager`, `CPhone`) VALUES
(1, 'Mangalore', 'Ajay', 8965741236),
(2, 'Udupi', 'Suresh', 8596321470),
(3, 'Bantwal', 'Sarika', 8965741230),
(4, 'Ullal', 'Akash', 7896547821),
(5, 'Bangalore', 'Akshay', 8529631475);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `DID` int(11) NOT NULL,
  `Dname` varchar(25) NOT NULL,
  `Dage` int(10) NOT NULL,
  `Daddress` varchar(50) NOT NULL,
  `Phnum` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`DID`, `Dname`, `Dage`, `Daddress`, `Phnum`) VALUES
(1, 'Shreya', 34, 'Mangalore', 9567541523),
(2, 'Ananya', 35, 'Mangalore', 7896547852),
(3, 'Seetharam', 40, 'Mangalore', 7898748596),
(4, 'Charles', 46, 'Mangalore', 9865896587),
(5, 'Anika', 50, 'Mangaluru', 7878968574),
(6, 'Sharmila', 39, 'Mangalore', 8974589658);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Pname` varchar(50) NOT NULL,
  `Gender` enum('F','M','O') NOT NULL,
  `Age` int(25) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Phno` bigint(12) NOT NULL,
  `AdmissionDate` date NOT NULL,
  `DischargeDate` date NOT NULL,
  `DID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Pname`, `Gender`, `Age`, `Address`, `Phno`, `AdmissionDate`, `DischargeDate`, `DID`) VALUES
('tara', 'F', 40, 'Mangalore', 7897859641, '2021-01-11', '0000-00-00', 3),
('Mishka', 'F', 60, 'Mangalore', 7898748596, '2021-01-04', '0000-00-00', 2),
('Aradhya', 'F', 30, 'Manglore', 8797586941, '2021-01-03', '0000-00-00', 4),
('Asmi', 'O', 25, 'Mangaluru', 8799984758, '2021-01-02', '0000-00-00', 3),
('Anush', 'M', 56, 'Mangalore', 8965741589, '2020-12-30', '2021-01-06', 1),
('Sameera', 'F', 27, 'Mangalore', 8974589652, '2021-01-09', '2021-01-10', 5);

-- --------------------------------------------------------

--
-- Table structure for table `patienttestreport`
--

CREATE TABLE `patienttestreport` (
  `Phno` bigint(11) NOT NULL,
  `TestType` enum('RT-PCR','RAPID ANTIGEN') NOT NULL,
  `Report` enum('POSITIVE','NEGATIVE') NOT NULL,
  `DateofTest` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patienttestreport`
--

INSERT INTO `patienttestreport` (`Phno`, `TestType`, `Report`, `DateofTest`) VALUES
(7898748596, 'RT-PCR', 'NEGATIVE', '2021-01-05'),
(8965741589, 'RT-PCR', 'POSITIVE', '2021-01-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`Bid`);

--
-- Indexes for table `covidcarecentre`
--
ALTER TABLE `covidcarecentre`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`DID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Phno`);

--
-- Indexes for table `patienttestreport`
--
ALTER TABLE `patienttestreport`
  ADD PRIMARY KEY (`Phno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `Bid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `covidcarecentre`
--
ALTER TABLE `covidcarecentre`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `DID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
