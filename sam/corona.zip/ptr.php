<?php
    $Phno=$_POST['Phno'];
	$TestType=$_POST['TestType'];
    $Report=$_POST['Report'];
    $DateofTest=$_POST['DateofTest'];
	
    
    
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    else {
        $stmt=$conn->prepare("insert into patienttestreport(Phno,TestType,Report,DateofTest)
            values(?,?,?,?)");
            $stmt->bind_param("issi",$Phno,$TestType,$Report,$DateofTest);
            $stmt->execute();
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: coronahome.php");
           // include 'home.php';
            $stmt->close();
           // $conn->close();
    }

    
        
?>