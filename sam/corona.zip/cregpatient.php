
<?php
    $Pname=$_POST['Pname'];
	$Gender=$_POST['Gender'];
    $Age=$_POST['Age'];
    $Address=$_POST['Address'];
	$Phno=$_POST['Phno'];
    $AdmissionDate=$_POST['AdmissionDate'];
    $DischargeDate=$_POST['DischargeDate'];
	$DID=$_POST['DID'];
    
    
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    else {
        $stmt=$conn->prepare("insert into patient(Pname,Gender,Age,Address,Phno,AdmissionDate,DischargeDate,DID)
            values(?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssisissi",$Pname,$Gender,$Age,$Address,$Phno,$AdmissionDate,$DischargeDate,$DID);
			   // mysql_query("UPDATE patient SET DischargeDate = '$DischargeDate'WHERE Phno = $Phno");

            $stmt->execute();
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: coronahome.php");
           // include 'home.php';
            $stmt->close();
           // $conn->close();
    }

    
        
?>