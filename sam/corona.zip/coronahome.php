<!DOCTYPE html>
<html lang="en">
<head>
  <title>Corona Care Center </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"> </script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"> </script>
  <script         src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<body style="background-image:url('c2.jpg');background-repeat:no-repeat;background-size:1550px ;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
<a class="navbar-brand" href="#">

<h3>CORONA CARE CENTER</h3>
</a>
<ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">HOME</a>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        REGISTER
      </a>
	  <div class="dropdown-menu">
        <a class="dropdown-item" href="patientreg.php">Patient Details</a>
        <a class="dropdown-item" href="docreg.php">Doctor Details</a>
		</div>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        VIEW
      </a>
	  <div class="dropdown-menu">
        <a class="dropdown-item" href="patientDetailView.php">Patient Details</a>
        <a class="dropdown-item" href="doctorDetailView.php">Doctor Details</a>
		<a class="dropdown-item" href="ptrview.php">Patient Test Report</a>
		<a class="dropdown-item" href="ccbview.php">Care Center Branch</a>
		</div>
    </li>
	<li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        UPDATE
      </a>
	  <div class="dropdown-menu">
        <a class="dropdown-item" href="billing.php">Bill</a>
        <a class="dropdown-item" href="p.php">Patient Report</a>
		<a class="dropdown-item" href="discharge.php">Patient Discharge Details</a>
		</div>
    </li>
	
	
	<li class="nav-item">
      <a class="nav-link" href="coronalogin.php">LOGOUT</a>
    </li>
</ul>
</nav>
</body>
</html>