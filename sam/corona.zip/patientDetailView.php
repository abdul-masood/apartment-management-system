<!DOCTYPE html>
<html lang="en">
<head>
  <title>Patient Details </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"> </script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"> </script>
  <script         src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

</head>
<body style="bgcolor:red;background-image:url('p.jpg');background-repeat:no-repeat;background-size:1550px ;">
<center>
<h3><b><u>Details of Patient</b></u></h3></center>

<?php
$connection = new mysqli('localhost','root','','coronacarecenter'); //The Blank string is the password


$sql = "SELECT * FROM patient p,doctor d where p.did=d.did";
$result =  $connection->query($sql);

//echo "Details of Patient";
echo "<table width='800' border='1' align='center' >"; 
// start a table tag in the HTML
echo"<tr>
	<th>Pname</th>
	<th>Gender</th>
	<th>Age</th>
	<th>Address</th>
	<th>Phno</th>
	<th>AdmissionDate</th>
	<th>DischargeDate</th>.
	<th>Dname</th>
	<th>Dage</th>
	<th>Daddress</th>
	
	<th>Phnum</th>
	</tr>";
while($row = $result->fetch_array(MYSQLI_BOTH)){   //Creates a loop to loop through results
echo "<tr border: '1px solid black'><td border: '1px solid black'>" . $row['Pname'] . "</td>
		<td border: '1px solid black'>" . $row['Gender'] . "</td>
		<td border: '1px solid black'>" . $row['Age'] . "</td>
		<td border: '1px solid black'>" . $row['Address'] . "</td>
		<td border: '1px solid black'>" . $row['Phno'] . "</td>
		<td border: '1px solid black'>" . $row['AdmissionDate'] . "</td>
		<td border: '1px solid black'>" . $row['DischargeDate'] . "</td>
		<td border: '1px solid black'>" . $row['Dname'] . "</td>
		<td border: '1px solid black'>" . $row['Dage'] . "</td>
		<td border: '1px solid black'>" . $row['Daddress'] . "</td>
		<td border: '1px solid black'>" . $row['Phnum'] . "</td>
		</tr>";  //$row['index'] the index here is a field name
}

echo "</table>"; //Close the table in HTML

//mysql_close();
?><br/>
<center><a href="coronahome.php" class="btn btn-danger">HomePage</a>
</center>
</body>
</head>
</html>