<?php
$host="localhost";
$text="root";
$password="";
$db="regtest";

mysql_connect($host,$text,$password,$db);
//$conn= new mysqli('localhost','root','','regtest');
mysql_select_db($db);
if(isset($_POST['text'])){
    $uname=$_POST['text'];
    $password=$_POST['password'];
    $sql="select * from login where User='".$uname."'AND Pass='".$password."'limit 1 ";
    $result=mysql_query($sql);
    if(mysql_num_rows($result)==1){
        echo "You have successfully logged in";
        exit();
    }
    else {
        echo "You have entered incorrect password";
        exit();
    }
}






?>
