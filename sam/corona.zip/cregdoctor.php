<?php
    $Dname=$_POST['Dname'];
    $Dage=$_POST['Dage'];
    $Daddress=$_POST['Daddress'];
	$Phnum=$_POST['Phnum']; 
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)//if there is an error
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    //connection successful
    else {
        $stmt=$conn->prepare("insert into doctor(Dname,Dage,Daddress,Phnum)
            values(?,?,?,?)");
            $stmt->bind_param("sisi",$Dname,$Dage,$Daddress,$Phnum);
            $stmt->execute();
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: coronahome.php");
            //include 'home.php';
            $stmt->close();
           // $conn->close();
    }

    
        
?>