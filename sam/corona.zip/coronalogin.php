<?php
   include("configuration.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT id FROM loginform WHERE user = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //ṣ$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("myusername");
        // $_SESSION['login_user'] = $myusername;
         
         header("location: coronahome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie-edge">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <script src='https://kit.fontawesome.com/a076d05399.js'></script>
        <link href='https://fonts.googleapis.com/css?family=KronaOne' rel='stylesheet'>
        <!--<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">-->
         <link rel="icon" type="image/png" href="assets/img/favicon.ico">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <title>Login</title>
   <!--<script type="text/javascript">
    function matchpass(){
                var firstpassword=document.f1.password.value;
                var secondpassword=document.f1.password2.value;

                if(firstpassword==secondpassword){
					
                return true;
                }
                else{
                alert("password must be same!");
                return false;
                    }
                 }
</script>-->
         <style>
		 body{
			background-image: url('doc.jpg'); 
			width:100%; 
			background-size: cover;
		 }
		 @media screen and (max-width: 600px) {
			  .column {
				width: 100%;
				display: block;
				margin-bottom: 20px;
			  }
			}

			.card {
			  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			  max-width: 450px;
			  
			  margin: auto;
			 /* text-align: center;*/
			  font-family: arial;
			  border-radius: 10px;
			}

			.title {
			  color: grey;
			  font-size: 18px;
			}

			.button2 {
			  border: none;
			  outline: 0;
			  display: inline-block;
			  padding: 8px;
			  color: white;
			  margin: 30px;
			  background-color: #e6007a;
			  text-align: center;
			  align: centre;
			  cursor: pointer;
			  width: 50%;
			  font-size: 18px;
			  border-radius: 5%;
			}
			.h1s{
				padding-top: 50px;
			}
			#i1{
				font-size:15px;
				color: gray;
				text-align: left;

			}
			.in{
				border: none;
				color: gray;
				background: transparent;
				line-height: 1.2;
				outline: none;
				width: 75%;
				
			}
			.p1{
				padding-left: 40px;
			}
			hr{
			color: black;
			}
			.wrap-input {
				width: 90%;
				position: relative;
				border-bottom: 2px solid #d9d9d9;
			}
			/* unvisited link */
			a1:link {
			  color: black;
			}

			/* visited link */
			a1:visited {
			  color: black;
			}

			/* mouse over link */
			a1:hover {
			  color: purple;
			}

			/* selected link */
			a1:active {
			  color: blue;
			}
			.text-right {
				text-align: right;
			}
			.button1 {
				  position: relative;
				  background: rgb(0,177,255);
				background: linear-gradient(90deg, rgba(0,177,255,0.9755252442773985) 0%, rgba(247,52,230,1) 62%);
				  border: none;
				  /*font-size: 18px;*/
				  color: #FFFFFF;
				  padding: 13px;
				  margin-top: 30px;
				   margin-bottom: 60px;
				  width: 370px;
				  text-align: center;
				  transition-duration: 0.4s;
				  text-decoration: none;
				  overflow: hidden;
				  cursor: pointer;
				   outline: none;
				   border-radius: 50px;
				   font-family: arial;
				   box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);

				display: -webkit-box;
				display: -webkit-flex;
				display: -moz-box;
				display: -ms-flexbox;
				display: flex;
				flex-wrap: wrap;
				justify-content: center;


				}

				.button1:after {

				  content: "";
				  background:pink;
				  display: block;
				  position: absolute;
				  padding-top: 300%;
				  padding-left: 350%;
				  margin-left: -20px !important;
				  margin-top: -120%;
				  opacity: 0;
				   outline: none;
				  transition: all 0.8s
				}
				.button1:hover {background: rgb(247,52,230);
				background: linear-gradient(90deg, rgba(247,52,230,1) 0%, rgba(0,177,255,0.9755252442773985) 70%);}
				.button1:active:after {
				  padding: 0;
				  background:pink;
				  margin: 0;
				  opacity: 1;
				  transition: 0s;
				  outline: none;
				  
				}
				.p2{
					padding-top: 154px;
					padding-bottom: 50px;
				}
				.fa {
				  padding-left: 20px;
				  padding-right: 20px;
				  font-size: 25px;
				 /* width: 20px;*/
				  text-align: center;
				  text-decoration: none;
				 margin: 5px 2px;
				  border-radius: 50%;
				  padding-bottom: 15px;
				  padding-top: 15px;
				}

				.fa:hover {
					opacity: 0.7;
					background-color: black;
				}

				.fa-facebook {
				  background: #3B5998;
				  color: white;
				}

				.fa-twitter {
				  background: #55ACEE;
				  color: white;
				}

				.fa-google {
				  background: #dd4b39;
				  color: white;
				}
				
		
  input:focus, textarea:focus, select:focus{
      outline: none;}
</style>


	</head>
		 <body >
		 <!--<form  name="f1" action="home.html" onsubmit = "return validate()"  method="POST">-->
		 <form action = "" method = "post">
			<div class="row" >
				<div class="col-sm-3">
				</div>
				<div class="col-sm-6">
					<div class="card" style="background-color: white;">
					  
					  <h1 class="text-center h1s"><b>Login</b></h1><br>
					  <div class="p1">
					  <div class=" wrap-input" style="margin-bottom: 25px;">
					  <h5><label>Username</label></h5>
					  <p><i  id="i1"class="far fa-user"></i> &nbsp <input class="in" type="text" name="username" id="username" placeholder="Type your username"></p></div>
					  <div class=" wrap-input">
					  <h5><label>Password</label></h5>
					  <p><i class="fas fa-lock" style='color:gray'></i> &nbsp
                       <input class="in" type="password"  id="password" name="password" placeholder="Type your password"></p></div>
					  </div>
					 
						<center><button class="button1" value="submit" type="submit">LOGIN</button> </center>
						
					 <p style="padding-top:10px;"></p>
					  
					</div>
				</div>
				<div class="col-sm-3">
				</div>
			</div>
			</form>
			<!--</form>-->
			
		 </body>
</html>	