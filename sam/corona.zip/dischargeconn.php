
<?php
	$Phno=$_POST['Phno'];
    
    $DischargeDate=$_POST['DischargeDate'];
	
    
   
    
    //database connection
    $conn= new mysqli('localhost','root','','coronacarecenter');
    if($conn->connect_error)
    {
        die('Connection Failed: '.$conn->connect_error);
    }
    else {
		$q1=mysqli_query($conn,"UPDATE patient SET DischargeDate = '$DischargeDate' WHERE Phno = '$Phno'");
	}
        //$stmt=$conn->prepare("insert into patient(Phno,DischargeDate)
            //values(?,?)");
           // $stmt->bind_param("is",$Phno,$DischargeDate);
			   // mysql_query("UPDATE patient SET DischargeDate = '$DischargeDate'WHERE Phno = $Phno");
           // $stmt->execute();
		   if(q1)
		   {
            echo'<script>alert("Registered Successfully:)")</script>';
			header("location: coronahome.php");
		   }
           // include 'home.php';
           // $stmt->close();
           // $conn->close();
    

    
        
?>